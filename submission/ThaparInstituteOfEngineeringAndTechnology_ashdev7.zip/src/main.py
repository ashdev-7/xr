#!/usr/bin/env python3
"""PathGuard: trust-aware inertial navigation under progressive sensor degradation.

Samsung PRISM XR Hackathon 2026, Track 03 (Path Finder).

    python main.py [imu0/data.csv | dataset folder | dataset .zip] [estimated_trajectory.txt] [--param=value ...]

Input : EuRoC-format IMU CSV (#timestamp[ns], w_x, w_y, w_z [rad/s], a_x, a_y, a_z [m/s^2]).
Output: TUM trajectory (timestamp[s] tx ty tz qx qy qz qw), exactly one pose per input row, including
        duplicated rows and the dead rows of the 5 s after the IMU fails. Nothing is appended.

Pure Python standard library (no numpy, nothing to install). The input is streamed twice; memory grows
with 40 ms bins and 10 Hz knots, never with the number of rows. This file is standalone: the pipeline stages
are embedded below and compiled one at a time to keep peak memory low (readable copies: src/stages/).

  pass 1       survey (header, column order, units) + one streaming pass: integrity checks (NaN, dead,
               frozen/duplicate rows, six-channel spikes), jamming meter (packet loss, noise levels),
               preintegration into bins, rest statistics
  platform     rotor-vibration signature -> rotorcraft or handheld motion prior (learned per class)
  attitude     error-state Kalman filter on [dtheta (world), gyro bias] + error-state RTS smoother;
               gravity-direction updates, zero-angular-rate updates at rest
  translation  per-axis Kalman filter + RTS smoother on 10 Hz knots, x = [p, v, accel bias, centre],
               continuous-time motion prior, zero-velocity updates at rest, rotor-drag velocity
               measurement for multirotors; the blind window is the same smoother with no data
  pass 2       one pose per input row: attitude interpolated between bins, position by cubic Hermite
"""
import math
import os
import sys
from array import array

# ----------------------------------------------------------------------------- parameters
P = dict(
    bin_dt=0.04,        # attitude/preintegration bin [s] (25 Hz: -24 % runtime, -28 % heap for ~0.3 % ATE)
    knot_dt=0.1,        # translation smoother step [s] (rounded to whole bins: 0.08 s with 0.04 s bins)
    res_T=300.0,        # logs longer than this [s] get proportionally coarser bins/knots (bounded memory)
    # attitude
    tilt_sig=0.5,       # gravity-direction measurement noise per update [rad]
    tilt_k=4.0,         # extra tilt noise per | |f| - g | [rad per m/s^2]
    tilt_gate=3.0,      # skip gravity update if | |f| - g | exceeds this [m/s^2]
    tilt_every=1,       # gravity update every N bins
    gyro_floor=2e-3,    # minimum gyro white noise per sample [rad/s]
    bg_rw=2e-5,         # base gyro bias random walk [rad/s/sqrt(s)]
    bg_k=0.002,         # extra gyro bias RW per unit severity [rad/s/sqrt(s)] (script: 6e-4 aware, ~1e-3..1e-2 as-is)
    gap_gyro_k=10.0,    # gyro noise inflation inside gaps
    gap_alpha=2.0,      # unknown angular acceleration inside data gaps [rad/s^2] (rotation uncertainty ~ alpha L^1.5)
    bg0_sig=0.05,       # initial gyro bias uncertainty [rad/s] (EuRoC raw bias reaches ~0.08)
    # translation (per-second parameterisation, independent of knot_dt)
    sig_a=0.4,          # accel noise per knot [m/s^2] (scaled by sqrt(noise ratio))
    sig_gap=3.0,        # accel uncertainty in the blind window after the failure [m/s^2]
    sig_gap_in=1.5,     # accel uncertainty inside data gaps (dropouts) [m/s^2]
    ba_rw=5e-4,         # base accel bias random walk [m/s^2/sqrt(s)]
    ba_k=0.01,          # extra accel bias RW per unit severity [m/s^2/sqrt(s)] (script: 0.01 aware)
    ba_kz=0.015,        # extra vertical bias RW per unit severity (1.5e-3 scale drift x g)
    ba_rw_z=-1.0,       # vertical accel bias RW [m/s^2/sqrt(s)]; < 0: same as horizontal (ba_rw)
    ba_k_z=0.0,         # vertical: extra bias RW per unit severity (used when ba_rw_z >= 0)
    sig_c=0.2,          # workspace-centre random walk [m/sqrt(s)]
    sig_v_h=0.3,        # speed prior, horizontal [m/s]
    sig_v_z=0.1,        # speed prior, vertical [m/s]
    sig_p_h=1.0,        # workspace prior, horizontal [m]
    sig_p_z=0.5,        # workspace prior, vertical [m]
    blind_tau=-1.0,     # blind forecast: <0 smoother prior, 0 hold, >0 decaying velocity time constant [s]
    att_tau=0.3,        # blind attitude: 0 hold, >0 last body rate decaying with this time constant [s]
    # integrity
    spike_k=8.0,        # spike threshold in robust sigmas (must hold on all 6 channels)
    # still detection (zero-velocity / zero-angular-rate updates), 0.5 s windows
    still_g=0.04,       # max gyro std [rad/s]
    still_a=1.0,        # max accel std [m/s^2]
    still_dg=0.3,       # max | |mean f| - g | [m/s^2]
    zupt_sig=0.02,      # zero-velocity pseudo-measurement noise [m/s]
    zaru_sig=0.002,     # zero-angular-rate measurement noise floor [rad/s]
    still_tilt=0.02,    # gravity-direction noise while still [rad]
    # rotor drag (rotorcraft only): the body-horizontal specific force of a multirotor is -mu * v_body
    drag=1,             # use the rotor-drag velocity measurement when the platform is a rotorcraft
    drag_mu=0.18,       # linear drag coefficient [1/s] (fitted on TRAIN flights: 0.18-0.20)
    drag_sig=1.2,       # velocity noise of one 10 Hz drag measurement [m/s]
    drag_vib=0.4,       # rotors spinning and airborne when accel vibration exceeds this [m/s^2]
    # platform: -1 auto (rotor vibration signature), 0 handheld/ground, 1 rotorcraft
    platform=-1,
    vib_thr=0.15,       # median accel white noise [m/s^2] above which the platform is a rotorcraft
    # features
    backward=1, adapt=1, repair=1, still=1, verbose=0,
)

# Motion priors learned per platform class on TRAIN flights (tools/bench/tune.py). Rotor vibration makes
# the class unambiguous: median accel noise 0.5-1.0 m/s^2 on EuRoC MAV, ~0.03 on handheld TUM-VI.
PRESETS = {
    1: dict(sig_v_h=4.0, sig_p_h=10.0, sig_a=0.1, ba_rw=0.04, ba_k=0.04, sig_c=0.05, tilt_sig=0.25, tilt_k=2.0,
            sig_gap=6.0, bg0_sig=0.005, blind_tau=0.0,
            # vertical: no drag measurement disciplines it, so it gets a physical bias random walk and loose priors
            # (QA audit: height was flattened, z std 0.02 m vs 0.49 m true; held-out RPE 1 s 0.351 -> 0.307 m)
            sig_v_z=1.0, sig_p_z=5.0, ba_rw_z=0.0005, ba_k_z=0.01),  # rotorcraft (tuned on MH_01/03/05, V1_01, V2_02)
    0: dict(sig_v_h=1.96, sig_p_h=1.5, sig_a=0.05, ba_rw=0.02, ba_k=0.028, sig_c=0.1, tilt_sig=0.25,
            bg0_sig=0.005),  # handheld (tuned on room1/3/5, validated on room2/4/6; final refit on all six: sig_a 0.1 -> 0.05)
}
CLI_SET = set()  # parameters given on the command line override the presets


def log(*a):
    if P["verbose"]:
        print(*a, file=sys.stderr)


# ----------------------------------------------------------------------------- input handling
def resolve_input(arg):
    """Accept a CSV, a dataset folder, or a zip; returns an opener for a fresh text stream."""
    cands = ("imu0/data.csv", "mav0/imu0/data.csv", "data.csv")
    if arg is None:
        arg = "."
    if os.path.isdir(arg):
        for c in cands:
            p = os.path.join(arg, c)
            if os.path.isfile(p):
                return (lambda p=p: open(p, "r", newline=None, encoding="utf-8-sig", errors="replace")), p
        for root, _dirs, files in os.walk(arg):
            if "data.csv" in files and os.path.basename(root) == "imu0":
                p = os.path.join(root, "data.csv")
                return (lambda p=p: open(p, "r", newline=None, encoding="utf-8-sig", errors="replace")), p
        zips = [f for f in os.listdir(arg) if f.lower().endswith(".zip")]
        if len(zips) == 1:
            arg = os.path.join(arg, zips[0])
        else:
            raise SystemExit(f"no imu0/data.csv found under {arg}")
    if arg.lower().endswith(".zip"):
        import io
        import zipfile  # imported only for zip input (the module alone costs ~1 MB of heap)
        z = zipfile.ZipFile(arg)
        real = [n for n in z.namelist() if "__MACOSX/" not in n and not n.rsplit("/", 1)[-1].startswith("._")]
        names = [n for n in real if n.endswith("imu0/data.csv")] or [n for n in real if n.lower().endswith(".csv")]
        if not names:
            raise SystemExit(f"no csv in {arg}")
        n = sorted(names, key=len)[0]
        return (lambda: io.TextIOWrapper(zipfile.ZipFile(arg).open(n), encoding="utf-8-sig", errors="replace", newline=None)), arg + ":" + n
    return (lambda: open(arg, "r", newline=None, encoding="utf-8-sig", errors="replace")), arg


def parse_ts(tok):
    """Timestamp token -> (int value or None, float value). Integers are kept exact."""
    try:
        return int(tok), None
    except ValueError:
        return None, float(tok)


# ----------------------------------------------------------------------------- pass 1a: format survey

# ----------------------------------------------------------------------------- BEGIN EMBEDDED STAGES
# Generated by tools/build_main.py from src/stages/*.py -- do not edit this section; edit the stage files.
# The pipeline is embedded as five stage texts and compiled one at a time into this module's namespace, so the
# code behaves exactly as one file while the transient parsing cost stays small (parsing all ~1,100 lines at
# once costs ~7 MB of heap; one stage at a time <= ~2 MB). Tracebacks name the stage file and its line.

_STAGES = (
    ('pg_ingest', r'''# PathGuard stage file: pass 1: survey of the input and the single streaming pass (integrity, jamming meter, preintegration, rest statistics).
# Embedded verbatim into the standalone src/main.py by tools/build_main.py and executed there, in main.py's namespace:
# it uses the imports (math, array, os, sys), parameters P and helpers defined in main.py.
# Edit here, then run: python tools/build_main.py   (tests/test_build.py checks main.py is up to date).

def survey(opener, nmax=4000):
    """Pre-read up to nmax data rows: header, column order, units, nominal sample period."""
    header = None
    rows = 0
    first_ts = first_tsf = prev = None
    is_int = True
    dts, n13, n46 = [], [], []
    head_ts = []
    with opener() as f:
        for line in f:
            s = line.strip()
            if not s:
                continue
            if not (s[0].isdigit() or s[0] in "+-."):
                if header is None and rows == 0:
                    header = s if ("," in s or ";" not in s) else s.replace(";", ",")
                    if "," not in header:
                        header = ",".join(header.split())
                continue
            if "," not in s:  # tolerate ';' or tab/whitespace delimiters (EuRoC uses ',')
                s = s.replace(";", ",") if ";" in s else ",".join(s.split())
            if " " in s or "\t" in s:
                s = s.replace(" ", "").replace("\t", "")
            parts = s.split(",")
            try:
                ti, tf = parse_ts(parts[0])
            except ValueError:
                continue
            rows += 1
            if ti is None:
                is_int = False
            if len(head_ts) < 64:
                head_ts.append((ti, tf))
            cur = ti if ti is not None else tf
            if prev is not None and cur > prev:
                dts.append(cur - prev)
            prev = cur
            if len(parts) >= 7:
                try:
                    v = [float(x) for x in parts[1:7]]
                except ValueError:
                    v = None
                if v and all(math.isfinite(x) for x in v) and any(v):
                    n13.append(math.sqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2]))
                    n46.append(math.sqrt(v[3] * v[3] + v[4] * v[4] + v[5] * v[5]))
            if rows >= nmax:
                break
        # count the remaining lines (no parsing): the log length sets the time resolution (see run)
        more = 0
        for line in f:
            more += 1
    if rows < 3:
        raise ValueError("input has fewer than 3 IMU rows")
    # timestamp unit -> seconds (same rule as the official degradation script)
    dts.sort()
    md = dts[len(dts) // 2] if dts else 1
    tscale = 1.0 if md < 1.0 else 1e-3 if md < 1e3 else 1e-6 if md < 1e6 else 1e-9
    dt_nom = md * tscale if dts else 0.005
    vals = [ti if ti is not None else tf for ti, tf in head_ts]
    k0 = 0
    for i in range(len(vals)):
        nxt = vals[i:i + 6]
        if len(nxt) == 6 and all(0 <= (b - a) * tscale <= 0.5 for a, b in zip(nxt[:-1], nxt[1:])):
            k0 = i
            break
    first_ts, first_tsf = head_ts[k0]
    # column layout: header names first, gravity magnitude as fallback
    gyro_first = True
    if header:
        h = [x.strip().lower() for x in header.lstrip("#").split(",")]
        kind = lambda n: ("g" if n.startswith("w") or "gyr" in n or "rad" in n else
                          "a" if n.startswith("a") or "acc" in n or "m s^-2" in n or "m/s" in n else "?")
        if len(h) < 7 or "?" in (kind(h[1]), kind(h[4])):
            header = None
        elif kind(h[1]) == "a" and kind(h[4]) == "g":
            gyro_first = False
    med = lambda x: sorted(x)[len(x) // 2] if x else 0.0
    # Physics decides when it is unambiguous: the accelerometer triple has a median magnitude of ~9.81 m/s^2
    # (or ~1 g); header names are used only when the magnitudes cannot tell (e.g. a gyro median near 1 rad/s)
    phys = None
    if n13:
        m13, m46 = med(n13), med(n46)
        near = lambda m, g, tol: abs(m - g) <= tol
        if near(m46, 9.80665, 1.5) != near(m13, 9.80665, 1.5) and not (near(m13, 9.80665, 3.0) and near(m46, 9.80665, 3.0)):
            phys = near(m46, 9.80665, 1.5)
        elif near(m46, 1.0, 0.15) != near(m13, 1.0, 0.15) and not (near(m13, 1.0, 0.5) and near(m46, 1.0, 0.5)):
            phys = near(m46, 1.0, 0.15)
    if phys is not None:
        gyro_first = phys
    elif not header and n13:  # weak evidence: the closer triple to gravity
        gs = lambda m: min(abs(m - 9.80665), abs(m - 1.0) * 9.80665)
        gyro_first = gs(med(n46)) <= gs(med(n13))
    ma = med(n46) if gyro_first else med(n13)
    return dict(header=header, tscale=tscale, dt_nom=dt_nom, gyro_first=gyro_first,
                ascale=9.80665 if 0.5 < ma < 2.0 else 1.0, is_int=is_int, first_ts=first_ts, first_tsf=first_tsf,
                dur_est=(rows + more) * dt_nom)


# ----------------------------------------------------------------------------- pass 1b: one-pass ingest
def ingest(opener, info):
    """Single streaming pass over all rows:
      * integrity: NaN/short rows, dead (all-zero) rows, frozen/duplicate rows (exact repeats), spikes
      * jamming meter: per-second robust white-noise level of gyro and accel (MAD of second
        differences) and unique timestamps present (-> packet loss)
      * preintegration of valid rows into bins (sum of gyro and accel, count)
      * 0.5 s window moments for rest detection
    Spike rule (signature of the jamming model): the SAME sample jumps on all six channels at once by
    more than spike_k robust sigmas from the median of its two neighbours on each side (measured on
    labelled official degradations: precision 0.97, recall 0.85; a per-channel rule: precision 0.16)."""
    t0i, t0f, tsc = info["first_ts"], info["first_tsf"], info["tscale"]
    gf, asc, dt_nom = info["gyro_first"], info["ascale"], info["dt_nom"]
    bdt = P["bin_dt"]
    kk, repair = P["spike_k"], P["repair"]
    isfin = math.isfinite
    gsum, asum, cnt = array("d"), array("d"), array("H")   # per bin
    ws = array("d")                                          # per 0.5 s window: n, sum w, sum w^2, sum f, sum f^2
    sg, sa, present = array("f"), array("f"), array("H")    # per second
    bg, ba = [], []
    w_idx = npres = 0
    last_t = last = p1 = p2 = None
    t_last_valid = t_acc = 0.0
    st = dict(rows=0, nan=0, dead=0, frozen=0, spikes=0, valid=0)
    buf = []
    sig_g, sig_a = 0.01, 0.1
    lo_dt, hi_dt = 0.5 * dt_nom, 1.5 * dt_nom

    def emit(r):
        tt = r[0]
        b = int(tt / bdt)
        while len(cnt) <= b:
            gsum.extend((0.0, 0.0, 0.0)); asum.extend((0.0, 0.0, 0.0)); cnt.append(0)
        i3 = 3 * b
        gsum[i3] += r[1]; gsum[i3 + 1] += r[2]; gsum[i3 + 2] += r[3]
        asum[i3] += r[4]; asum[i3 + 1] += r[5]; asum[i3 + 2] += r[6]
        if cnt[b] < 65535:
            cnt[b] += 1
        k = int(tt * 2.0)
        while len(ws) <= 13 * k:
            ws.extend((0.0,) * 13)
        o = 13 * k
        _, g0, g1, g2, a0, a1, a2 = r
        ws[o] += 1.0
        ws[o + 1] += g0; ws[o + 2] += g1; ws[o + 3] += g2
        ws[o + 4] += g0 * g0; ws[o + 5] += g1 * g1; ws[o + 6] += g2 * g2
        ws[o + 7] += a0; ws[o + 8] += a1; ws[o + 9] += a2
        ws[o + 10] += a0 * a0; ws[o + 11] += a1 * a1; ws[o + 12] += a2 * a2
        st["valid"] += 1

    def spike(i):
        r = buf[i]
        o0, o1, o2, o3 = [buf[j] for j in range(5) if j != i]
        for c in range(1, 7):
            v = sorted((o0[c], o1[c], o2[c], o3[c]))
            if abs(r[c] - 0.5 * (v[1] + v[2])) <= kk * (sig_g if c <= 3 else sig_a):
                return False
        return True

    with opener() as f:
        for line in f:
            s = line.strip()
            if not s or not (s[0].isdigit() or s[0] in "+-."):
                continue
            if "," not in s:  # tolerate ';' or tab/whitespace delimiters (EuRoC uses ',')
                s = s.replace(";", ",") if ";" in s else ",".join(s.split())
            if " " in s or "\t" in s:
                s = s.replace(" ", "").replace("\t", "")
            parts = s.split(",")
            try:  # parse_ts, inlined (hot loop)
                ti, tf = int(parts[0]), None
            except ValueError:
                try:
                    ti, tf = None, float(parts[0])
                except ValueError:
                    continue
            st["rows"] += 1
            t = (ti - t0i) * tsc if (ti is not None and t0i is not None) else \
                ((ti if ti is not None else tf) - (t0i if t0i is not None else t0f)) * tsc
            if t < 0.0 or t > t_last_valid + 60.0 or (last_t is not None and t < last_t):
                st["nan"] += 1  # out-of-order or glitched timestamp: still gets a pose, not used for estimation
                continue
            t_acc = t
            while t >= w_idx + 1.0:  # close the per-second window
                sg.append(_mad_sigma(bg)); sa.append(_mad_sigma(ba)); present.append(min(npres, 65535))
                if sg[-1] > 0:
                    sig_g = sg[-1]
                if sa[-1] > 0:
                    sig_a = sa[-1]
                bg, ba = [], []; npres = 0; w_idx += 1
            if t != last_t:
                npres += 1
                last_t = t
            try:
                v = (float(parts[1]), float(parts[2]), float(parts[3]), float(parts[4]), float(parts[5]), float(parts[6]))
            except (ValueError, IndexError):
                st["nan"] += 1
                continue
            if not (isfin(v[0]) and isfin(v[1]) and isfin(v[2]) and isfin(v[3]) and isfin(v[4]) and isfin(v[5])):
                st["nan"] += 1
                continue
            if not (v[0] or v[1] or v[2] or v[3] or v[4] or v[5]):
                st["dead"] += 1
                last = v
                continue
            if v == last:
                st["frozen"] += 1
                continue
            last = v
            r = (t, v[0], v[1], v[2], v[3] * asc, v[4] * asc, v[5] * asc) if gf else \
                (t, v[3], v[4], v[5], v[0] * asc, v[1] * asc, v[2] * asc)
            t_last_valid = t
            if p1 is not None and p2 is not None:  # second differences for the noise meter
                d1, d2 = t - p1[0], p1[0] - p2[0]
                if lo_dt < d1 < hi_dt and lo_dt < d2 < hi_dt:
                    bg.extend((abs(r[1] - 2 * p1[1] + p2[1]), abs(r[2] - 2 * p1[2] + p2[2]), abs(r[3] - 2 * p1[3] + p2[3])))
                    ba.extend((abs(r[4] - 2 * p1[4] + p2[4]), abs(r[5] - 2 * p1[5] + p2[5]), abs(r[6] - 2 * p1[6] + p2[6])))
            p2, p1 = p1, r
            if not repair:
                emit(r)
                continue
            buf.append(r)
            if len(buf) == 5:
                if spike(2):
                    st["spikes"] += 1
                    del buf[2]
                else:
                    emit(buf.pop(0))
    for r in buf:  # the last rows before the failure have no two-sided window
        emit(r)
    sg.append(_mad_sigma(bg)); sa.append(_mad_sigma(ba)); present.append(min(npres, 65535))
    nb = int(t_last_valid / bdt) + 1
    while len(cnt) < nb:
        gsum.extend((0.0, 0.0, 0.0)); asum.extend((0.0, 0.0, 0.0)); cnt.append(0)
    return dict(sg=sg, sa=sa, present=present, T_L=t_last_valid, t_end=t_acc, gsum=gsum, asum=asum, cnt=cnt,
                nb=nb, ws=ws, nwin=len(ws) // 13, stats=st)


def _mad_sigma(x):
    """Robust white-noise sigma from |second differences|. Exact zeros are dropped: they come from interpolated,
    duplicated or quantised samples, not from sensor noise (a median of zeros would make every sample a spike)."""
    x = [v for v in x if v > 0.0]
    if len(x) < 30:
        return -1.0
    x.sort()
    return 1.4826 * x[len(x) // 2] / math.sqrt(6.0)


def smooth_levels(sig, T_L):
    """Fill missing windows and apply a 5-window running median (robust per-second noise level)."""
    n = len(sig)
    good = [x for i, x in enumerate(sig) if x > 0 and i <= T_L]
    fill = sorted(good)[len(good) // 2] if good else 0.0
    v = [x if x > 0 else -1.0 for x in sig]
    out = array("f", bytes(4 * n))
    for i in range(n):
        w = [x for x in v[max(0, i - 2):i + 3] if x > 0]
        out[i] = sorted(w)[len(w) // 2] if w else fill
    return out


def fit_severity(present, dt_nom, T_L, T_end):
    """Jamming level from packet loss. The official degradation drops rows with probability
    0.06 s per row plus bursts (start prob 0.0015 s, length U[5, 5 + 45 s]); s(t) = L (t/T)^gamma is the
    single severity that also scales noise, bias drift, scale drift, spikes and frozen samples.
    Fit (L, gamma) by least squares on the per-second missing-row counts (failure window excluded)."""
    exp_per_win = 1.0 / dt_nom
    pts = []
    for i, n in enumerate(present):
        if i + 1.0 > T_L or i < 2:  # skip the failure window, the last partial second and the protected start
            continue
        pts.append(((i + 0.5) / max(T_end, 1e-9), max(0.0, exp_per_win - n) / exp_per_win))
    if len(pts) < 5:
        return 0.0, 1.7

    # expected missing fraction miss(s) = 0.06 s + 0.0015 s (5 + 22.5 s) = 0.0675 s + 0.03375 s^2
    best = (1e30, 0.0, 1.7)

    def fit_L(g):
        xs = [r ** g for r, _ in pts]
        ys = [y for _, y in pts]
        lo, hi = 0.0, 3.0
        for _ in range(28):  # ternary search on L (convex for fixed gamma)
            m1, m2 = lo + (hi - lo) / 3, hi - (hi - lo) / 3
            e1 = e2 = 0.0
            for x, y in zip(xs, ys):
                u1 = m1 * x; u2 = m2 * x
                d1 = 0.0675 * u1 + 0.03375 * u1 * u1 - y; d2 = 0.0675 * u2 + 0.03375 * u2 * u2 - y
                e1 += d1 * d1; e2 += d2 * d2
            if e1 < e2:
                hi = m2
            else:
                lo = m1
        Lh = 0.5 * (lo + hi)
        e = 0.0
        for x, y in zip(xs, ys):
            u = Lh * x; d = 0.0675 * u + 0.03375 * u * u - y; e += d * d
        return e, Lh
    for g in (0.5, 1.0, 1.5, 2.0, 2.5, 3.0, 3.5, 4.0):
        e, Lh = fit_L(g)
        if e < best[0]:
            best = (e, Lh, g)
    g0 = best[2]
    for g in (g0 - 0.375, g0 - 0.25, g0 - 0.125, g0 + 0.125, g0 + 0.25, g0 + 0.375):
        if g <= 0.25:
            continue
        e, Lh = fit_L(g)
        if e < best[0]:
            best = (e, Lh, g)
    return best[1], best[2]


def still_windows(ws, nwin, gmag):
    """0.5 s windows in which the body is at rest: low gyro and accel spread and |f| ~ g.
    Chosen on ground-truth-labelled windows for ~zero false positives (a false zero-velocity
    update in flight would hurt far more than a missed one). A window counts only if a
    neighbour is also still (>= 1 s of rest)."""
    dt_nom = INFO["dt_nom"]
    raw = array("b", bytes(nwin))
    for k in range(nwin):
        o = 13 * k
        n = ws[o]
        if n < 0.6 * 0.5 / dt_nom:
            continue
        vg = va = 0.0
        for c in range(3):
            m = ws[o + 1 + c] / n
            vg += max(0.0, ws[o + 4 + c] / n - m * m)
            m = ws[o + 7 + c] / n
            va += max(0.0, ws[o + 10 + c] / n - m * m)
        fm = math.sqrt(sum((ws[o + 7 + c] / n) ** 2 for c in range(3)))
        if math.sqrt(vg) < P["still_g"] and math.sqrt(va) < P["still_a"] and abs(fm - gmag) < P["still_dg"]:
            raw[k] = 1
    out = array("b", bytes(nwin))
    for k in range(nwin):
        if raw[k] and ((k > 0 and raw[k - 1]) or (k + 1 < nwin and raw[k + 1])):
            out[k] = 1
    return out


# ----------------------------------------------------------------------------- rotation helpers
'''),
    ('pg_math', r'''# PathGuard stage file: quaternion / 3x3 helpers and the attitude error-state Kalman filter (class Att).
# Embedded verbatim into the standalone src/main.py by tools/build_main.py and executed there, in main.py's namespace:
# it uses the imports (math, array, os, sys), parameters P and helpers defined in main.py.
# Edit here, then run: python tools/build_main.py   (tests/test_build.py checks main.py is up to date).

def qmul(a, b):
    aw, ax, ay, az = a
    bw, bx, by, bz = b
    return (aw * bw - ax * bx - ay * by - az * bz, aw * bx + ax * bw + ay * bz - az * by,
            aw * by - ax * bz + ay * bw + az * bx, aw * bz + ax * by - ay * bx + az * bw)


def qexp(x, y, z):
    a = math.sqrt(x * x + y * y + z * z)
    if a < 1e-12:
        return (1.0, 0.5 * x, 0.5 * y, 0.5 * z)
    s = math.sin(0.5 * a) / a
    return (math.cos(0.5 * a), s * x, s * y, s * z)


def qnorm(q):
    n = 1.0 / math.sqrt(q[0] * q[0] + q[1] * q[1] + q[2] * q[2] + q[3] * q[3])
    return (q[0] * n, q[1] * n, q[2] * n, q[3] * n)


def qlog(q):
    w, x, y, z = q
    if w < 0:
        w, x, y, z = -w, -x, -y, -z
    vn = math.sqrt(x * x + y * y + z * z)
    if vn < 1e-12:
        return (2 * x, 2 * y, 2 * z)
    a = 2 * math.atan2(vn, w) / vn
    return (a * x, a * y, a * z)


def qrot(q, v):
    """R(q) v, q body->world."""
    w, x, y, z = q
    vx, vy, vz = v
    tx = 2 * (y * vz - z * vy); ty = 2 * (z * vx - x * vz); tz = 2 * (x * vy - y * vx)
    return (vx + w * tx + y * tz - z * ty, vy + w * ty + z * tx - x * tz, vz + w * tz + x * ty - y * tx)


def qmat(q):
    w, x, y, z = q
    return ((1 - 2 * (y * y + z * z), 2 * (x * y - w * z), 2 * (x * z + w * y)),
            (2 * (x * y + w * z), 1 - 2 * (x * x + z * z), 2 * (y * z - w * x)),
            (2 * (x * z - w * y), 2 * (y * z + w * x), 1 - 2 * (x * x + y * y)))


# 3x3 helpers on tuples-of-tuples (row major)
def m3mul(A, B):
    return tuple(tuple(A[i][0] * B[0][j] + A[i][1] * B[1][j] + A[i][2] * B[2][j] for j in range(3)) for i in range(3))


def m3T(A):
    return ((A[0][0], A[1][0], A[2][0]), (A[0][1], A[1][1], A[2][1]), (A[0][2], A[1][2], A[2][2]))


def m3add(A, B, s=1.0):
    return tuple(tuple(A[i][j] + s * B[i][j] for j in range(3)) for i in range(3))


def m3inv(A):
    a, b, c = A[0]; d, e, f = A[1]; g, h, i = A[2]
    co0, co1, co2 = e * i - f * h, f * g - d * i, d * h - e * g
    det = a * co0 + b * co1 + c * co2
    if abs(det) < 1e-300:
        return None
    r = 1.0 / det
    return ((co0 * r, (c * h - b * i) * r, (b * f - c * e) * r),
            (co1 * r, (a * i - c * g) * r, (c * d - a * f) * r),
            (co2 * r, (b * g - a * h) * r, (a * e - b * d) * r))


def m3sym(A):
    return tuple(tuple(0.5 * (A[i][j] + A[j][i]) for j in range(3)) for i in range(3))


Z3 = ((0.0, 0.0, 0.0), (0.0, 0.0, 0.0), (0.0, 0.0, 0.0))


def diag3(a):
    return ((a, 0.0, 0.0), (0.0, a, 0.0), (0.0, 0.0, a))


# ----------------------------------------------------------------------------- stage C: attitude
class Att:
    """ESKF on [dtheta (world frame), dbg (body)]. R_true = Exp(dtheta) R_hat.

    In the world frame the gravity measurement only sees roll/pitch (dtheta_x, dtheta_y),
    so the update is a 2-D measurement; heading is propagated by the gyro only.
    Covariance blocks: A = cov(dtheta), B = cov(dtheta, dbg), C = cov(dbg)."""
    __slots__ = ("q", "bg", "A", "B", "C")

    def __init__(self, q, bg, sth, syaw, sbg):
        self.q = q; self.bg = bg
        self.A = ((sth * sth, 0.0, 0.0), (0.0, sth * sth, 0.0), (0.0, 0.0, syaw * syaw))
        self.B = Z3
        self.C = diag3(sbg * sbg)

    def predict(self, w, dt, qg2, qb2):
        """Propagate over dt (negative = backward) with body rate w. qg2: rotation noise var added,
        qb2: bias RW var added.  Error model: dtheta' = dtheta - dt R dbg  (F = [[I, -dt R], [0, I]]):
            A' = A - dt (R B' + B R') + dt^2 R C R' + qg2 I,   B' = B - dt R C,   C' = C + qb2 I."""
        bg = self.bg
        q = self.q
        qw, qx, qy, qz = q
        self.q = qnorm(qmul(q, qexp((w[0] - bg[0]) * dt, (w[1] - bg[1]) * dt, (w[2] - bg[2]) * dt)))
        # rotation matrix of the pre-step attitude
        r00 = 1 - 2 * (qy * qy + qz * qz); r01 = 2 * (qx * qy - qw * qz); r02 = 2 * (qx * qz + qw * qy)
        r10 = 2 * (qx * qy + qw * qz); r11 = 1 - 2 * (qx * qx + qz * qz); r12 = 2 * (qy * qz - qw * qx)
        r20 = 2 * (qx * qz - qw * qy); r21 = 2 * (qy * qz + qw * qx); r22 = 1 - 2 * (qx * qx + qy * qy)
        (a00, a01, a02), (_, a11, a12), (_, _, a22) = self.A
        (b00, b01, b02), (b10, b11, b12), (b20, b21, b22) = self.B
        (c00, c01, c02), (_, c11, c12), (_, _, c22) = self.C
        # RC = R C
        e00 = r00 * c00 + r01 * c01 + r02 * c02; e01 = r00 * c01 + r01 * c11 + r02 * c12; e02 = r00 * c02 + r01 * c12 + r02 * c22
        e10 = r10 * c00 + r11 * c01 + r12 * c02; e11 = r10 * c01 + r11 * c11 + r12 * c12; e12 = r10 * c02 + r11 * c12 + r12 * c22
        e20 = r20 * c00 + r21 * c01 + r22 * c02; e21 = r20 * c01 + r21 * c11 + r22 * c12; e22 = r20 * c02 + r21 * c12 + r22 * c22
        # M = R B'  (M_ij = sum_k R_ik B_jk)
        m00 = r00 * b00 + r01 * b01 + r02 * b02; m01 = r00 * b10 + r01 * b11 + r02 * b12; m02 = r00 * b20 + r01 * b21 + r02 * b22
        m10 = r10 * b00 + r11 * b01 + r12 * b02; m11 = r10 * b10 + r11 * b11 + r12 * b12; m12 = r10 * b20 + r11 * b21 + r12 * b22
        m20 = r20 * b00 + r21 * b01 + r22 * b02; m21 = r20 * b10 + r21 * b11 + r22 * b12; m22 = r20 * b20 + r21 * b21 + r22 * b22
        # S = R C R'
        s00 = e00 * r00 + e01 * r01 + e02 * r02; s01 = e00 * r10 + e01 * r11 + e02 * r12; s02 = e00 * r20 + e01 * r21 + e02 * r22
        s11 = e10 * r10 + e11 * r11 + e12 * r12; s12 = e10 * r20 + e11 * r21 + e12 * r22
        s22 = e20 * r20 + e21 * r21 + e22 * r22
        d2 = dt * dt
        n00 = a00 - 2 * dt * m00 + d2 * s00 + qg2
        n01 = a01 - dt * (m01 + m10) + d2 * s01
        n02 = a02 - dt * (m02 + m20) + d2 * s02
        n11 = a11 - 2 * dt * m11 + d2 * s11 + qg2
        n12 = a12 - dt * (m12 + m21) + d2 * s12
        n22 = a22 - 2 * dt * m22 + d2 * s22 + qg2
        self.A = ((n00, n01, n02), (n01, n11, n12), (n02, n12, n22))
        self.B = ((b00 - dt * e00, b01 - dt * e01, b02 - dt * e02),
                  (b10 - dt * e10, b11 - dt * e11, b12 - dt * e12),
                  (b20 - dt * e20, b21 - dt * e21, b22 - dt * e22))
        self.C = ((c00 + qb2, c01, c02), (c01, c11 + qb2, c12), (c02, c12, c22 + qb2))

    def zero_rate(self, w, sig):
        """At rest the true rate is zero: z = w - bg ~ N(0, sig^2) measures the gyro bias on all three axes
        (including the one about gravity, which tilt updates cannot see). H = [0 I]."""
        A, B, C = self.A, self.B, self.C
        z = (w[0] - self.bg[0], w[1] - self.bg[1], w[2] - self.bg[2])
        S = m3add(C, diag3(sig * sig))
        Si = m3inv(S)
        if Si is None:
            return
        KA = m3mul(B, Si)          # gain for dtheta  (3x3) = B S^-1
        KC = m3mul(C, Si)          # gain for dbg     (3x3) = C S^-1
        dth = tuple(KA[i][0] * z[0] + KA[i][1] * z[1] + KA[i][2] * z[2] for i in range(3))
        dbg = tuple(KC[i][0] * z[0] + KC[i][1] * z[1] + KC[i][2] * z[2] for i in range(3))
        self.q = qnorm(qmul(qexp(dth[0], dth[1], dth[2]), self.q))
        self.bg = (self.bg[0] + dbg[0], self.bg[1] + dbg[1], self.bg[2] + dbg[2])
        Bt = m3T(B)
        # P <- P - K [B' C]:  A -= KA B',  B -= KA C,  C -= KC C
        self.A = m3sym(m3add(A, m3mul(KA, Bt), -1.0))
        self.B = m3add(B, m3mul(KA, C), -1.0)
        self.C = m3sym(m3add(C, m3mul(KC, C), -1.0))

    def gravity(self, f, sig):
        """f: mean body specific force. Measurement z = (R f / |f|)_xy  ~ (-dth_y, dth_x)."""
        n = math.sqrt(f[0] * f[0] + f[1] * f[1] + f[2] * f[2])
        if n < 1e-6:
            return
        wx, wy, _wz = qrot(self.q, (f[0] / n, f[1] / n, f[2] / n))
        A, B = self.A, self.B
        # H selects (-A row y, A row x): z1 = -dth_y, z2 = dth_x
        # P H^T columns: for theta block  col1 = -A[:,1], col2 = A[:,0]; for bias block col1 = -B^T[:,1], col2 = B^T[:,0]
        s11 = A[1][1] + sig * sig
        s12 = -A[1][0]
        s22 = A[0][0] + sig * sig
        det = s11 * s22 - s12 * s12
        if det <= 0:
            return
        i11, i12, i22 = s22 / det, -s12 / det, s11 / det
        # PHt rows (6 x 2)
        # cov(dbg_r, dtheta_c) = B[c][r]
        PH = [(-A[r][1], A[r][0]) for r in range(3)] + [(-B[1][r], B[0][r]) for r in range(3)]
        K = [(ph[0] * i11 + ph[1] * i12, ph[0] * i12 + ph[1] * i22) for ph in PH]
        z1, z2 = wx, wy
        dx = [k[0] * z1 + k[1] * z2 for k in K]
        # apply: R <- Exp(dth) R ; bg <- bg + dbg
        self.q = qnorm(qmul(qexp(dx[0], dx[1], dx[2]), self.q))
        self.bg = (self.bg[0] + dx[3], self.bg[1] + dx[4], self.bg[2] + dx[5])
        # P <- P - K (H P) ; (H P) rows: row1 = -P[1,:], row2 = P[0,:]   (P = [[A, B],[B^T, C]])
        Prow0 = (A[0][0], A[0][1], A[0][2], B[0][0], B[0][1], B[0][2])
        Prow1 = (A[1][0], A[1][1], A[1][2], B[1][0], B[1][1], B[1][2])
        HP0 = tuple(-x for x in Prow1)
        HP1 = Prow0
        full = [[0.0] * 6 for _ in range(6)]
        Pm = [list(A[0]) + list(B[0]), list(A[1]) + list(B[1]), list(A[2]) + list(B[2]),
              [B[0][0], B[1][0], B[2][0]] + list(self.C[0]),
              [B[0][1], B[1][1], B[2][1]] + list(self.C[1]),
              [B[0][2], B[1][2], B[2][2]] + list(self.C[2])]
        for r in range(6):
            kr0, kr1 = K[r]
            row = Pm[r]
            full[r] = [row[c] - kr0 * HP0[c] - kr1 * HP1[c] for c in range(6)]
        for r in range(6):
            for c in range(r + 1, 6):
                m = 0.5 * (full[r][c] + full[c][r]); full[r][c] = full[c][r] = m
        self.A = tuple(tuple(full[r][0:3]) for r in range(3))
        self.B = tuple(tuple(full[r][3:6]) for r in range(3))
        self.C = tuple(tuple(full[r][3:6]) for r in range(3, 6))
'''),
    ('pg_attitude', r'''# PathGuard stage file: initial attitude, attitude filter + RTS smoother.
# Embedded verbatim into the standalone src/main.py by tools/build_main.py and executed there, in main.py's namespace:
# it uses the imports (math, array, os, sys), parameters P and helpers defined in main.py.
# Edit here, then run: python tools/build_main.py   (tests/test_build.py checks main.py is up to date).

def initial_attitude(gsum, asum, cnt, nb):
    """Gravity direction (roll, pitch; yaw = 0) and gyro bias from the calmest early second."""
    bdt = P["bin_dt"]
    per = max(1, int(round(1.0 / bdt)))
    lim = min(nb, int(60.0 / bdt))
    best, bestv = 0, 1e30
    for s in range(0, max(1, lim - per + 1), max(1, per // 4)):
        n = 0; m = [0.0] * 3; m2 = [0.0] * 3
        for b in range(s, min(nb, s + per)):
            c = cnt[b]
            if not c:
                continue
            for k in range(3):
                w = gsum[3 * b + k] / c
                m[k] += w; m2[k] += w * w
            n += 1
        if n < per // 2:
            continue
        v = sum(m2[k] / n - (m[k] / n) ** 2 for k in range(3))
        if v < bestv:
            bestv, best = v, s
    am = [0.0] * 3; wm = [0.0] * 3; n = 0
    for b in range(best, min(nb, best + per)):
        c = cnt[b]
        if c:
            for k in range(3):
                am[k] += asum[3 * b + k]; wm[k] += gsum[3 * b + k]
            n += c
    if n == 0:
        return (1.0, 0.0, 0.0, 0.0), (0.0, 0.0, 0.0), 9.81, best, bestv
    am = [x / n for x in am]; wm = [x / n for x in wm]
    g = math.sqrt(sum(x * x for x in am))
    still = bestv < 2.5e-3 * 0.25 and abs(g - 9.81) < 0.5  # bin-mean variance is ~4x lower than per-sample
    bg0 = tuple(wm) if still else (0.0, 0.0, 0.0)
    u = [x / g for x in am]
    # rotation taking body "up" u to world z: axis u x z = (u_y, -u_x, 0), angle atan2(|u x z|, u.z)
    ax, ay = u[1], -u[0]
    s = math.sqrt(ax * ax + ay * ay)
    cth = u[2]
    if s < 1e-9:
        q0 = (1.0, 0.0, 0.0, 0.0) if cth > 0 else (0.0, 1.0, 0.0, 0.0)
    else:
        ang = math.atan2(s, cth)
        q0 = qexp(ax / s * ang, ay / s * ang, 0.0)
    # roll back from the calm window to t = 0 with the gyro
    for b in range(best - 1, -1, -1):
        c = cnt[b]
        if c:
            w = [gsum[3 * b + k] / c - bg0[k] for k in range(3)]
            q0 = qnorm(qmul(q0, qexp(-w[0] * bdt, -w[1] * bdt, -w[2] * bdt)))
    return q0, bg0, g, best, bestv


def attitude(gsum, asum, cnt, nb, T_L, gmag):
    """Forward ESKF + error-state RTS smoother over bins; returns the smoothed quaternion at every bin
    boundary (nb + 1 entries) and the gyro bias at the end of the forward pass."""
    bdt = P["bin_dt"]
    every = max(1, int(P["tilt_every"]))
    dt_nom = INFO["dt_nom"]
    adapt = P["adapt"]
    n_tilt = max(1.0, every * bdt / dt_nom)  # samples averaged per gravity update

    # gyro for empty bins: linear interpolation between neighbouring filled bins (filled in place)
    filled = array("b", bytes(nb))
    glen = array("f", bytes(4 * nb))  # length [s] of the data gap each empty bin belongs to
    for b in range(nb):
        filled[b] = 1 if cnt[b] else 0
    b = 0
    while b < nb:
        if filled[b]:
            b += 1; continue
        a0 = b
        while b < nb and not filled[b]:
            b += 1
        left = a0 - 1 if a0 > 0 else (b if b < nb else None)
        right = b if b < nb else left
        if left is None:
            break
        wl = [gsum[3 * left + k] / cnt[left] for k in range(3)]
        wr = [gsum[3 * right + k] / cnt[right] for k in range(3)]
        span = right - left if right != left else 1
        for j in range(a0, b):
            glen[j] = (b - a0) * bdt
            s = (j - left) / span if right != left else 0.0
            for k in range(3):
                gsum[3 * j + k] = (1 - s) * wl[k] + s * wr[k]
            # cnt stays 0: marks interpolated

    def gyro_var(b):
        """Rotation noise variance over one bin: measured white gyro noise integrated over the bin."""
        sg_ = max(sigma_g(b * bdt), P["gyro_floor"]) if adapt else P["gyro_floor"]
        v = sg_ * sg_ * dt_nom * bdt
        if not cnt[b]:
            # inside a data gap the rate is interpolated; the unknown angular acceleration makes the rotation
            # error grow like alpha * L per bin (total variance ~ alpha^2 L^3): ~2 deg for a 0.25 s burst,
            # ~0.8 rad for a 2 s signal loss, so gravity can re-level the attitude right after a long gap
            v = max(v * P["gap_gyro_k"] ** 2, (P["gap_alpha"] * glen[b] * bdt) ** 2)
        return v

    def bias_var(b):
        q = P["bg_rw"] + (P["bg_k"] * sev_at(b * bdt) if adapt else 0.0)
        return q * q * bdt

    def is_still(b):
        if STILL is None:
            return False
        k = int(b * bdt * 2.0)
        return 0 <= k < len(STILL) and STILL[k] == 1

    def tilt_sig(f, b):
        n = math.sqrt(f[0] * f[0] + f[1] * f[1] + f[2] * f[2])
        dev = abs(n - gmag)
        if is_still(b):
            return P["still_tilt"]
        if dev > P["tilt_gate"]:
            return None
        s2 = P["tilt_sig"] ** 2 + (P["tilt_k"] * dev) ** 2
        if adapt:
            sa_ = sigma_a(b * bdt)
            s2 += sa_ * sa_ / (n_tilt * gmag * gmag)
        return math.sqrt(s2)

    q0, bg0, _g, _best, _v = INIT

    def rate(b):
        c = cnt[b]
        if c:
            return (gsum[3 * b] / c, gsum[3 * b + 1] / c, gsum[3 * b + 2] / c)
        return (gsum[3 * b], gsum[3 * b + 1], gsum[3 * b + 2])  # interpolated (empty bin)

    # ---- forward ESKF; store posterior nominal state and covariance at every bin boundary
    F = Att(q0, bg0, 0.02, 0.02, P["bg0_sig"])
    nq = nb + 1
    qf = array("f", bytes(4 * 4 * nq))      # quaternion (w, x, y, z)
    bgf = array("f", bytes(4 * 3 * nq))     # gyro bias
    Pf = array("f", bytes(4 * 21 * nq))     # upper triangle of the 6x6 covariance

    def store(i, Fi):
        q = Fi.q
        qf[4 * i] = q[0]; qf[4 * i + 1] = q[1]; qf[4 * i + 2] = q[2]; qf[4 * i + 3] = q[3]
        bgf[3 * i] = Fi.bg[0]; bgf[3 * i + 1] = Fi.bg[1]; bgf[3 * i + 2] = Fi.bg[2]
        A, B, C = Fi.A, Fi.B, Fi.C
        Pf[21 * i:21 * i + 21] = array("f", (A[0][0], A[0][1], A[0][2], B[0][0], B[0][1], B[0][2],
                                             A[1][1], A[1][2], B[1][0], B[1][1], B[1][2],
                                             A[2][2], B[2][0], B[2][1], B[2][2],
                                             C[0][0], C[0][1], C[0][2], C[1][1], C[1][2], C[2][2]))

    acc = [0.0, 0.0, 0.0]; na = 0; since = 0
    store(0, F)
    for b in range(nb):
        F.predict(rate(b), bdt, gyro_var(b), bias_var(b))
        c = cnt[b]
        if c:
            acc[0] += asum[3 * b] / c; acc[1] += asum[3 * b + 1] / c; acc[2] += asum[3 * b + 2] / c; na += 1
        since += 1
        if since >= every and na:
            f = (acc[0] / na, acc[1] / na, acc[2] / na)
            s = tilt_sig(f, b)
            if s is not None:
                F.gravity(f, s)
            acc = [0.0, 0.0, 0.0]; na = 0; since = 0
        if c and is_still(b):
            sz = max(P["zaru_sig"], sigma_g(b * bdt) / math.sqrt(c))
            F.zero_rate(rate(b), sz)
        store(b + 1, F)
    bg_end = F.bg
    if not P["backward"]:
        return qf, bg_end

    # ---- error-state RTS smoother (backward). For each step k -> k+1:
    #   x_p(k+1) = f(x_f(k)),  P_p = F P_f F' + Q,   delta = P_f F' P_p^-1 (x_s(k+1) [-] x_p(k+1)),
    #   x_s(k) = x_f(k) [+] delta.  The smoothed gyro bias carries information from the whole flight
    #   back to t = 0, which makes heading consistent (the bias about the vertical is only weakly
    #   observable, through the times the body tilts).
    qs = (qf[4 * nb], qf[4 * nb + 1], qf[4 * nb + 2], qf[4 * nb + 3])
    bs = (bgf[3 * nb], bgf[3 * nb + 1], bgf[3 * nb + 2])
    out = qf  # overwritten in place from the end backwards (entry k+1 is no longer needed as filtered)
    tmp = Att((1.0, 0.0, 0.0, 0.0), (0.0, 0.0, 0.0), 0.0, 0.0, 0.0)
    for k in range(nb - 1, -1, -1):
        qk = (qf[4 * k], qf[4 * k + 1], qf[4 * k + 2], qf[4 * k + 3])
        bk = (bgf[3 * k], bgf[3 * k + 1], bgf[3 * k + 2])
        p = Pf[21 * k:21 * k + 21]
        A = ((p[0], p[1], p[2]), (p[1], p[6], p[7]), (p[2], p[7], p[11]))
        B = ((p[3], p[4], p[5]), (p[8], p[9], p[10]), (p[12], p[13], p[14]))
        C = ((p[15], p[16], p[17]), (p[16], p[18], p[19]), (p[17], p[19], p[20]))
        tmp.q, tmp.bg, tmp.A, tmp.B, tmp.C = qk, bk, A, B, C
        tmp.predict(rate(k), bdt, gyro_var(k), bias_var(k))
        # difference x_s(k+1) [-] x_p(k+1) in the world-frame error convention
        qp = tmp.q
        dth = qlog(qmul(qs, (qp[0], -qp[1], -qp[2], -qp[3])))
        d = [dth[0], dth[1], dth[2], bs[0] - tmp.bg[0], bs[1] - tmp.bg[1], bs[2] - tmp.bg[2]]
        y = chol_solve6(tmp.A, tmp.B, tmp.C, d)
        if y is None:
            qs, bs = qk, bk
        else:
            # F' y = (y_th, -dt R' y_th + y_b), R = R(q_f(k))
            R = qmat(qk)
            yt = y[0:3]
            z = (y[0], y[1], y[2],
                 y[3] - bdt * (R[0][0] * yt[0] + R[1][0] * yt[1] + R[2][0] * yt[2]),
                 y[4] - bdt * (R[0][1] * yt[0] + R[1][1] * yt[1] + R[2][1] * yt[2]),
                 y[5] - bdt * (R[0][2] * yt[0] + R[1][2] * yt[1] + R[2][2] * yt[2]))
            M = (A[0] + B[0], A[1] + B[1], A[2] + B[2],
                 (B[0][0], B[1][0], B[2][0]) + C[0], (B[0][1], B[1][1], B[2][1]) + C[1], (B[0][2], B[1][2], B[2][2]) + C[2])
            dl = [M[r][0] * z[0] + M[r][1] * z[1] + M[r][2] * z[2] + M[r][3] * z[3] + M[r][4] * z[4] + M[r][5] * z[5]
                  for r in range(6)]
            qs = qnorm(qmul(qexp(dl[0], dl[1], dl[2]), qk))
            bs = (bk[0] + dl[3], bk[1] + dl[4], bk[2] + dl[5])
        out[4 * k] = qs[0]; out[4 * k + 1] = qs[1]; out[4 * k + 2] = qs[2]; out[4 * k + 3] = qs[3]
    return out, bg_end
'''),
    ('pg_translation', r'''# PathGuard stage file: translation: per-axis Kalman filter + RTS smoother on ~10 Hz knots (0.08 s).
# Embedded verbatim into the standalone src/main.py by tools/build_main.py and executed there, in main.py's namespace:
# it uses the imports (math, array, os, sys), parameters P and helpers defined in main.py.
# Edit here, then run: python tools/build_main.py   (tests/test_build.py checks main.py is up to date).

def chol_solve6(A, B, C, d):
    """Solve P y = d for the symmetric positive-definite 6x6 P = [[A, B], [B', C]] (Cholesky)."""
    Pm = (A[0] + B[0], A[1] + B[1], A[2] + B[2],
          (B[0][0], B[1][0], B[2][0]) + C[0], (B[0][1], B[1][1], B[2][1]) + C[1], (B[0][2], B[1][2], B[2][2]) + C[2])
    L = [[0.0] * 6 for _ in range(6)]
    for i in range(6):
        Li = L[i]
        for j in range(i + 1):
            Lj = L[j]
            s = Pm[i][j]
            for k in range(j):
                s -= Li[k] * Lj[k]
            if i == j:
                if s <= 0.0:
                    return None
                Li[i] = math.sqrt(s)
            else:
                Li[j] = s / Lj[j]
    y = [0.0] * 6
    for i in range(6):
        s = d[i]
        Li = L[i]
        for k in range(i):
            s -= Li[k] * y[k]
        y[i] = s / Li[i]
    for i in range(5, -1, -1):
        s = y[i]
        for k in range(i + 1, 6):
            s -= L[k][i] * y[k]
        y[i] = s / L[i][i]
    return y


# ----------------------------------------------------------------------------- stage D: translation
def translation(asum, cnt, nb, qs, T_L, T_end):
    """World acceleration on knots -> per-axis Kalman filter + RTS smoother with motion prior."""
    bdt, kdt = P["bin_dt"], P["knot_dt"]
    per = max(1, int(round(kdt / bdt)))
    kdt = per * bdt
    K = int(math.ceil(T_end / kdt)) + 2
    KL = int(T_L / kdt)  # knots fully covered by data are < KL
    kacc = array("d", bytes(8 * 3 * K))
    kfb = array("d", bytes(8 * 3 * K))  # body-frame specific force (for the rotor-drag model)
    kcnt = array("H", bytes(2 * K))
    gz = 0.0; ng = 0
    # world-frame specific force per bin (mid-bin attitude) -> knot means
    for b in range(nb):
        c = cnt[b]
        if not c:
            continue
        q0 = (qs[4 * b], qs[4 * b + 1], qs[4 * b + 2], qs[4 * b + 3])
        q1 = (qs[4 * b + 4], qs[4 * b + 5], qs[4 * b + 6], qs[4 * b + 7])
        qm = qnorm((q0[0] + q1[0], q0[1] + q1[1], q0[2] + q1[2], q0[3] + q1[3]))
        fb = (asum[3 * b] / c, asum[3 * b + 1] / c, asum[3 * b + 2] / c)
        fw = qrot(qm, fb)
        j = b // per
        if j >= K:
            continue
        kacc[3 * j] += fw[0]; kacc[3 * j + 1] += fw[1]; kacc[3 * j + 2] += fw[2]
        kfb[3 * j] += fb[0]; kfb[3 * j + 1] += fb[1]; kfb[3 * j + 2] += fb[2]
        kcnt[j] += 1
        gz += fw[2]; ng += 1
    gz = gz / ng if ng else 9.81
    for j in range(K):
        if kcnt[j]:
            c = kcnt[j]
            kacc[3 * j] /= c; kacc[3 * j + 1] /= c; kacc[3 * j + 2] = kacc[3 * j + 2] / c - gz
            kfb[3 * j] /= c; kfb[3 * j + 1] /= c; kfb[3 * j + 2] /= c
    need = max(1, per // 3)
    adapt = P["adapt"]
    n_knot = max(1.0, kdt / INFO["dt_nom"])

    pos = array("d", bytes(8 * 3 * K))
    vel = array("d", bytes(8 * 3 * K))
    dt = kdt
    h = 0.5 * dt * dt
    # per-step model terms shared by the three axes: input known?, accel noise, bias random walk
    known = array("b", bytes(K))
    qa_ = array("d", bytes(8 * K))
    qbh_ = array("d", bytes(8 * K))
    qbz_ = array("d", bytes(8 * K))
    for j in range(K):
        tj = j * kdt
        kn = kcnt[j] >= need and j < KL + 1
        known[j] = 1 if kn else 0
        if kn:
            qa_[j] = P["sig_a"] ** 2 + (sigma_a(tj) ** 2 / n_knot if adapt else 0.0)
        else:  # no data: inside the log (dropout) or after the failure (blind window) use separate uncertainties
            qa_[j] = (P["sig_gap"] if tj > T_L else P["sig_gap_in"]) ** 2
        sv = sev_at(tj) if adapt else 0.0
        qb = P["ba_rw"] + P["ba_k"] * sv
        qbh_[j] = qb * qb * dt
        qbv = (P["ba_rw_z"] + P["ba_k_z"] * sv) if P["ba_rw_z"] >= 0 else qb  # vertical: own bias random walk
        qbz_[j] = (qbv * qbv + (P["ba_kz"] * sv) ** 2) * dt
    qc = P["sig_c"] ** 2 * dt
    g0, g1 = h, dt
    rz = P["zupt_sig"] ** 2
    zk = array("b", bytes(K))
    if STILL is not None:
        for j in range(K):
            k = int(j * kdt * 2.0)
            if 0 <= k < len(STILL) and STILL[k] and j * kdt <= T_L:
                zk[j] = 1
    # ---- rotor-drag velocity measurement (rotorcraft, rotors spinning, not at rest)
    # A multirotor's thrust acts along one body axis u, so the specific force perpendicular to u is rotor
    # drag: f_perp = -mu v_perp (Leishman et al. 2014). u = mean specific-force direction while airborne
    # (this also absorbs a constant accelerometer bias). The body velocity is rotated to the world frame
    # with the smoothed attitude and observed on the horizontal axes.
    dvel = None
    if PLATFORM == 1 and P["drag"]:
        air = array("b", bytes(K))
        su = [0.0, 0.0, 0.0]
        for j in range(K):
            if kcnt[j] >= need and j * kdt <= T_L and not zk[j] and sigma_a(j * kdt) > P["drag_vib"]:
                air[j] = 1
                su[0] += kfb[3 * j]; su[1] += kfb[3 * j + 1]; su[2] += kfb[3 * j + 2]
        nu = math.sqrt(su[0] ** 2 + su[1] ** 2 + su[2] ** 2)
        if nu > 0 and sum(air) * kdt > 5.0:
            u = (su[0] / nu, su[1] / nu, su[2] / nu)
            dvel = array("d", bytes(8 * 2 * K))
            mu = P["drag_mu"]
            for j in range(K):
                if not air[j]:
                    continue
                f0, f1, f2 = kfb[3 * j], kfb[3 * j + 1], kfb[3 * j + 2]
                fu = f0 * u[0] + f1 * u[1] + f2 * u[2]
                vb = (-(f0 - fu * u[0]) / mu, -(f1 - fu * u[1]) / mu, -(f2 - fu * u[2]) / mu)
                bm = min(nb, j * per + per // 2)
                vw = qrot((qs[4 * bm], qs[4 * bm + 1], qs[4 * bm + 2], qs[4 * bm + 3]), vb)
                dvel[2 * j] = vw[0]; dvel[2 * j + 1] = vw[1]
            DIAG["drag_knots"] = sum(air); DIAG["thrust_axis"] = u
    rd = P["drag_sig"] ** 2 * (0.1 / kdt)
    store = array("d", bytes(8 * 14 * K))  # filtered mean (4) + covariance upper triangle (10)
    for ax in range(3):
        horiz = ax < 2
        sv_ = P["sig_v_h"] if horiz else P["sig_v_z"]
        sp_ = P["sig_p_h"] if horiz else P["sig_p_z"]
        # continuous-time prior: pseudo-measurement variance scales with 1/rate so the prior's information
        # per second is independent of the knot spacing (values are calibrated at 10 Hz knots)
        rv, rp = sv_ * sv_ * (0.1 / dt), sp_ * sp_ * (0.1 / dt)
        qb_ = qbh_ if horiz else qbz_
        # state x = [p, v, b, c]; covariance entries named cIJ (symmetric)
        x0 = x1 = x2 = x3 = 0.0
        c00, c01, c02, c03, c11, c12, c13, c22, c23, c33 = 1e-6, 0.0, 0.0, 0.0, 0.5, 0.0, 0.0, 0.1, 0.0, rp
        for j in range(K):
            if j > 0:
                i = j - 1
                acc = kacc[3 * i + ax] if known[i] else 0.0
                qa = qa_[i]
                # mean: p += dt v - h b + h a ; v += -dt b + dt a
                x0 = x0 + dt * x1 - h * x2 + h * acc
                x1 = x1 - dt * x2 + dt * acc
                # covariance F C F' + Q with F = [[1, dt, -h, 0], [0, 1, -dt, 0], [0, 0, 1, 0], [0, 0, 0, 1]]
                t00 = c00 + dt * c01 - h * c02; t01 = c01 + dt * c11 - h * c12; t02 = c02 + dt * c12 - h * c22
                t03 = c03 + dt * c13 - h * c23
                t11 = c11 - dt * c12; t12 = c12 - dt * c22; t13 = c13 - dt * c23
                n00 = t00 + dt * t01 - h * t02
                n01 = t01 - dt * t02
                n02 = t02
                n03 = t03
                n11 = t11 - dt * t12
                n12 = t12
                n13 = t13
                c00 = n00 + g0 * g0 * qa; c01 = n01 + g0 * g1 * qa; c02 = n02; c03 = n03
                c11 = n11 + g1 * g1 * qa; c12 = n12; c13 = n13
                c22 = c22 + qb_[i]; c33 = c33 + qc
            # pseudo-measurement v = 0 (variance rv; much tighter at rest = zero-velocity update)
            S = c11 + (rz if zk[j] else rv)
            k0, k1, k2, k3 = c01 / S, c11 / S, c12 / S, c13 / S
            inn = -x1
            x0 += k0 * inn; x1 += k1 * inn; x2 += k2 * inn; x3 += k3 * inn
            p0, p1, p2, p3 = c01, c11, c12, c13
            c00 -= k0 * p0; c01 -= k0 * p1; c02 -= k0 * p2; c03 -= k0 * p3
            c11 -= k1 * p1; c12 -= k1 * p2; c13 -= k1 * p3
            c22 -= k2 * p2; c23 -= k2 * p3; c33 -= k3 * p3
            # rotor-drag velocity measurement v = v_drag (horizontal axes, airborne rotorcraft)
            if dvel is not None and ax < 2 and air[j]:
                S = c11 + rd
                k0, k1, k2, k3 = c01 / S, c11 / S, c12 / S, c13 / S
                inn = dvel[2 * j + ax] - x1
                x0 += k0 * inn; x1 += k1 * inn; x2 += k2 * inn; x3 += k3 * inn
                p0, p1, p2, p3 = c01, c11, c12, c13
                c00 -= k0 * p0; c01 -= k0 * p1; c02 -= k0 * p2; c03 -= k0 * p3
                c11 -= k1 * p1; c12 -= k1 * p2; c13 -= k1 * p3
                c22 -= k2 * p2; c23 -= k2 * p3; c33 -= k3 * p3
            # pseudo-measurement p - c = 0 (variance rp)
            p0, p1, p2, p3 = c00 - c03, c01 - c13, c02 - c23, c03 - c33
            S = p0 - p3 + rp
            k0, k1, k2, k3 = p0 / S, p1 / S, p2 / S, p3 / S
            inn = -(x0 - x3)
            x0 += k0 * inn; x1 += k1 * inn; x2 += k2 * inn; x3 += k3 * inn
            c00 -= k0 * p0; c01 -= k0 * p1; c02 -= k0 * p2; c03 -= k0 * p3
            c11 -= k1 * p1; c12 -= k1 * p2; c13 -= k1 * p3
            c22 -= k2 * p2; c23 -= k2 * p3; c33 -= k3 * p3
            o = 14 * j
            store[o] = x0; store[o + 1] = x1; store[o + 2] = x2; store[o + 3] = x3
            store[o + 4] = c00; store[o + 5] = c01; store[o + 6] = c02; store[o + 7] = c03; store[o + 8] = c11
            store[o + 9] = c12; store[o + 10] = c13; store[o + 11] = c22; store[o + 12] = c23; store[o + 13] = c33
        # RTS smoother (mean only): xs_j = xf_j + Pf F' Pp^-1 (xs_{j+1} - xp_{j+1})
        o = 14 * (K - 1)
        s0, s1, s2, s3 = store[o], store[o + 1], store[o + 2], store[o + 3]
        pos[3 * (K - 1) + ax] = s0; vel[3 * (K - 1) + ax] = s1
        for j in range(K - 2, -1, -1):
            o = 14 * j
            f0, f1, f2, f3 = store[o], store[o + 1], store[o + 2], store[o + 3]
            c00, c01, c02, c03, c11, c12, c13, c22, c23, c33 = store[o + 4:o + 14]
            acc = kacc[3 * j + ax] if known[j] else 0.0
            qa = qa_[j]
            # prediction j -> j+1 (same algebra as the forward pass)
            xp0 = f0 + dt * f1 - h * f2 + h * acc
            xp1 = f1 - dt * f2 + dt * acc
            t00 = c00 + dt * c01 - h * c02; t01 = c01 + dt * c11 - h * c12; t02 = c02 + dt * c12 - h * c22
            t03 = c03 + dt * c13 - h * c23
            t11 = c11 - dt * c12; t12 = c12 - dt * c22; t13 = c13 - dt * c23
            a00 = t00 + dt * t01 - h * t02 + g0 * g0 * qa
            a01 = t01 - dt * t02 + g0 * g1 * qa
            a02 = t02; a03 = t03
            a11 = t11 - dt * t12 + g1 * g1 * qa
            a12 = t12; a13 = t13
            a22 = c22 + qb_[j]; a23 = c23; a33 = c33 + qc
            # y = Pp^-1 d  (Cholesky of the 4x4 predicted covariance)
            d0, d1, d2, d3 = s0 - xp0, s1 - xp1, s2 - f2, s3 - f3
            if a00 <= 0:
                s0, s1, s2, s3 = f0, f1, f2, f3
            else:
                l00 = math.sqrt(a00); l10 = a01 / l00; l20 = a02 / l00; l30 = a03 / l00
                e = a11 - l10 * l10
                if e <= 0:
                    s0, s1, s2, s3 = f0, f1, f2, f3
                else:
                    l11 = math.sqrt(e); l21 = (a12 - l20 * l10) / l11; l31 = (a13 - l30 * l10) / l11
                    e = a22 - l20 * l20 - l21 * l21
                    if e <= 0:
                        s0, s1, s2, s3 = f0, f1, f2, f3
                    else:
                        l22 = math.sqrt(e); l32 = (a23 - l30 * l20 - l31 * l21) / l22
                        e = a33 - l30 * l30 - l31 * l31 - l32 * l32
                        if e <= 0:
                            s0, s1, s2, s3 = f0, f1, f2, f3
                        else:
                            l33 = math.sqrt(e)
                            z0 = d0 / l00; z1 = (d1 - l10 * z0) / l11; z2 = (d2 - l20 * z0 - l21 * z1) / l22
                            z3 = (d3 - l30 * z0 - l31 * z1 - l32 * z2) / l33
                            y3 = z3 / l33; y2 = (z2 - l32 * y3) / l22; y1 = (z1 - l21 * y2 - l31 * y3) / l11
                            y0 = (z0 - l10 * y1 - l20 * y2 - l30 * y3) / l00
                            # u = F' y ; delta = Pf u
                            u0 = y0; u1 = dt * y0 + y1; u2 = -h * y0 - dt * y1 + y2; u3 = y3
                            s0 = f0 + c00 * u0 + c01 * u1 + c02 * u2 + c03 * u3
                            s1 = f1 + c01 * u0 + c11 * u1 + c12 * u2 + c13 * u3
                            s2 = f2 + c02 * u0 + c12 * u1 + c22 * u2 + c23 * u3
                            s3 = f3 + c03 * u0 + c13 * u1 + c23 * u2 + c33 * u3
            pos[3 * j + ax] = s0; vel[3 * j + ax] = s1
    return pos, vel, K, kdt, gz


# ----------------------------------------------------------------------------- pass E: output
'''),
    ('pg_output', r'''# PathGuard stage file: pass 2 (one pose per input row) and the pipeline driver run().
# Embedded verbatim into the standalone src/main.py by tools/build_main.py and executed there, in main.py's namespace:
# it uses the imports (math, array, os, sys), parameters P and helpers defined in main.py.
# Edit here, then run: python tools/build_main.py   (tests/test_build.py checks main.py is up to date).

def write_output(opener, info, out_path, qs, nb, pos, vel, K, kdt, T_L, wL=(0.0, 0.0, 0.0)):
    bdt = P["bin_dt"]
    isint = info["is_int"] and info["tscale"] == 1e-9
    t0i, t0f, tsc = info["first_ts"], info["first_tsf"], info["tscale"]
    # attitude after failure: hold the last smoothed attitude
    nbo = nb  # boundary index of the last bin
    n_out = 0

    def hermite(t):
        uk = t / kdt
        j = int(uk) if uk > 0 else 0
        if j >= K - 1:
            j = K - 2
        sk = min(1.0, max(0.0, uk - j))
        s2, s3 = sk * sk, sk * sk * sk
        h00, h10, h01, h11 = 2 * s3 - 3 * s2 + 1, (s3 - 2 * s2 + sk) * kdt, -2 * s3 + 3 * s2, (s3 - s2) * kdt
        d00, d10, d01, d11 = (6 * s2 - 6 * sk) / kdt, 3 * s2 - 4 * sk + 1, (-6 * s2 + 6 * sk) / kdt, 3 * s2 - 2 * sk
        j3, j4 = 3 * j, 3 * j + 3
        p_ = [h00 * pos[j3 + c] + h10 * vel[j3 + c] + h01 * pos[j4 + c] + h11 * vel[j4 + c] for c in range(3)]
        v_ = [d00 * pos[j3 + c] + d10 * vel[j3 + c] + d01 * pos[j4 + c] + d11 * vel[j4 + c] for c in range(3)]
        return p_, v_
    # blind window (after the last valid sample): blind_tau < 0 -> the smoother's own prior-conditional
    # forecast; 0 -> hold the position at failure; > 0 -> velocity at failure decaying with time constant tau
    tau = P["blind_tau"]
    pL, vL = hermite(T_L)
    atau = P["att_tau"]
    t_att0 = max(T_L, nbo * bdt)
    buf = []
    with open(out_path, "w", newline="\n") as fo:
        fo.write("# timestamp tx ty tz qx qy qz qw\n")
        with opener() as f:
            for line in f:
                s = line.strip()
                if not s:
                    continue
                c = s[0]
                if not (c.isdigit() or c in "+-."):
                    continue
                if "," not in s:  # tolerate ';' or tab/whitespace delimiters (EuRoC uses ',')
                    s = s.replace(";", ",") if ";" in s else ",".join(s.split())
                k = s.find(",")
                tok = (s[:k] if k >= 0 else s).strip()
                try:  # parse_ts, inlined (hot loop)
                    ti, tf = int(tok), None
                except ValueError:
                    try:
                        ti, tf = None, float(tok)
                    except ValueError:
                        continue
                if ti is not None and t0i is not None:
                    t = (ti - t0i) * tsc
                else:
                    t = ((ti if ti is not None else tf) - (t0i if t0i is not None else t0f)) * tsc
                # timestamp string in seconds, exact
                if isint and ti is not None and ti >= 0:
                    ds = str(ti)
                    if len(ds) <= 9:
                        ds = "0" * (10 - len(ds)) + ds
                    ts_s = ds[:-9] + "." + ds[-9:]
                elif ti is not None:
                    ts_s = repr(ti * tsc)
                else:
                    ts_s = tok if tsc == 1.0 else repr(tf * tsc)
                # attitude: slerp-free normalized lerp between bin boundaries (bins are 20 ms)
                u = t / bdt
                if u >= nbo:
                    i = nbo; sfr = 0.0
                else:
                    i = int(u) if u > 0 else 0
                    sfr = u - i if u > 0 else 0.0
                if i >= nbo:
                    # blind window: continue the last body rate, decaying with time constant att_tau
                    qw, qx, qy, qz = qs[4 * nbo], qs[4 * nbo + 1], qs[4 * nbo + 2], qs[4 * nbo + 3]
                    if atau > 0 and t > t_att0:  # decay starts where the smoothed bins end: continuous
                        fa = atau * (1.0 - math.exp(-(t - t_att0) / atau))
                        qw, qx, qy, qz = qmul((qw, qx, qy, qz), qexp(wL[0] * fa, wL[1] * fa, wL[2] * fa))
                else:
                    a0, a1, a2, a3 = qs[4 * i], qs[4 * i + 1], qs[4 * i + 2], qs[4 * i + 3]
                    b0, b1, b2, b3 = qs[4 * i + 4], qs[4 * i + 5], qs[4 * i + 6], qs[4 * i + 7]
                    if a0 * b0 + a1 * b1 + a2 * b2 + a3 * b3 < 0:
                        b0, b1, b2, b3 = -b0, -b1, -b2, -b3
                    r = 1.0 - sfr
                    qw, qx, qy, qz = r * a0 + sfr * b0, r * a1 + sfr * b1, r * a2 + sfr * b2, r * a3 + sfr * b3
                n = 1.0 / math.sqrt(qw * qw + qx * qx + qy * qy + qz * qz)
                qw *= n; qx *= n; qy *= n; qz *= n
                if qw < 0:
                    qw, qx, qy, qz = -qw, -qx, -qy, -qz
                if tau >= 0 and t > T_L:
                    f_ = tau * (1.0 - math.exp(-(t - T_L) / tau)) if tau > 0 else 0.0
                    buf.append("%s %.6f %.6f %.6f %.9f %.9f %.9f %.9f\n" % (ts_s, pL[0] + f_ * vL[0], pL[1] + f_ * vL[1],
                                                                          pL[2] + f_ * vL[2], qx, qy, qz, qw))
                    n_out += 1
                    if len(buf) >= 2048:  # flush here too: a long dead tail must not accumulate in memory
                        fo.write(_no_negative_zero("".join(buf))); buf = []
                    continue
                # position: cubic Hermite between knots
                uk = t / kdt
                j = int(uk) if uk > 0 else 0
                if j >= K - 1:
                    j = K - 2
                sk = uk - j
                if sk < 0:
                    sk = 0.0
                elif sk > 1:
                    sk = 1.0
                s2, s3 = sk * sk, sk * sk * sk
                h00, h10, h01, h11 = 2 * s3 - 3 * s2 + 1, (s3 - 2 * s2 + sk) * kdt, -2 * s3 + 3 * s2, (s3 - s2) * kdt
                j3, j4 = 3 * j, 3 * j + 3
                px = h00 * pos[j3] + h10 * vel[j3] + h01 * pos[j4] + h11 * vel[j4]
                py = h00 * pos[j3 + 1] + h10 * vel[j3 + 1] + h01 * pos[j4 + 1] + h11 * vel[j4 + 1]
                pz = h00 * pos[j3 + 2] + h10 * vel[j3 + 2] + h01 * pos[j4 + 2] + h11 * vel[j4 + 2]
                buf.append("%s %.6f %.6f %.6f %.9f %.9f %.9f %.9f\n" % (ts_s, px, py, pz, qx, qy, qz, qw))
                n_out += 1
                if len(buf) >= 2048:
                    fo.write(_no_negative_zero("".join(buf))); buf = []
        if buf:
            fo.write(_no_negative_zero("".join(buf)))
    return n_out


def _no_negative_zero(text):
    """Print tiny negative values as 0.000000 rather than -0.000000 (fixed-width tokens, so exact)."""
    for _ in range(2):  # twice: adjacent tokens share a space, and str.replace does not overlap matches
        text = text.replace(" -0.000000000", " 0.000000000").replace(" -0.000000 ", " 0.000000 ")
    return text


# ----------------------------------------------------------------------------- main
INFO = {}
INIT = None
JAM = dict(L=0.0, gamma=1.7, T=1.0, sg=None, sa=None)
STILL = None  # per 0.5 s window: 1 if the body is at rest
PLATFORM = 0  # 1 rotorcraft, 0 handheld/ground
DIAG = {}


def sev_at(t):
    """Estimated jamming severity at time t (0 = clean, ~1 = maximum of the official script)."""
    r = t / JAM["T"]
    if r <= 0:
        return 0.0
    return JAM["L"] * (r if r < 1 else 1.0) ** JAM["gamma"]


def sigma_g(t):
    a = JAM["sg"]
    return a[min(len(a) - 1, int(t))] if t > 0 else a[0]


def sigma_a(t):
    a = JAM["sa"]
    return a[min(len(a) - 1, int(t))] if t > 0 else a[0]


def run(inp, out_path, hook=None):
    """Bounded memory: arrays grow with the number of attitude bins and position knots. Up to res_T seconds of
    log (all EuRoC flights and TUM-VI rooms) the nominal resolution is used; a longer log gets proportionally
    coarser bins and knots, so the estimator's memory stays ~constant (~4 MB traced) for any log length."""
    opener, src = resolve_input(inp)
    info = survey(opener)
    keep = (P["bin_dt"], P["knot_dt"])
    if info["dur_est"] > P["res_T"]:
        f = info["dur_est"] / P["res_T"]
        P["bin_dt"], P["knot_dt"] = keep[0] * f, keep[1] * f
    try:
        return _run(opener, src, info, out_path, hook)
    finally:
        P["bin_dt"], P["knot_dt"] = keep


def _run(opener, src, info, out_path, hook=None):
    """hook (development only): optional callable(stage, data) -> data, used by offline oracles."""
    global INFO, INIT, STILL, PLATFORM
    INFO = info
    d = ingest(opener, info)
    T_L, T_end, st = d["T_L"], max(d["t_end"], d["T_L"]), d["stats"]
    if st["valid"] < 10:
        raise ValueError("fewer than 10 valid IMU rows")
    sg = d["sg"]
    # platform class from the rotor-vibration signature (first half of the flight, before heavy jamming)
    half = [x for i, x in enumerate(d["sa"]) if x > 0 and i < 0.5 * T_L]
    vib = sorted(half)[len(half) // 2] if half else 0.0
    plat = int(P["platform"]) if P["platform"] >= 0 else (1 if vib > P["vib_thr"] else 0)
    PLATFORM = plat
    for k, v in PRESETS[plat].items():
        if k not in CLI_SET:
            P[k] = v
    L, gam = fit_severity(d["present"], info["dt_nom"], T_L, T_end)
    JAM.update(L=L, gamma=gam, T=max(T_end, 1e-9), sg=smooth_levels(sg, T_L), sa=smooth_levels(d["sa"], T_L))
    gsum, asum, cnt, nb, ws, nwin = d["gsum"], d["asum"], d["cnt"], d["nb"], d["ws"], d["nwin"]
    del d
    INIT = initial_attitude(gsum, asum, cnt, nb)
    gmag = INIT[2]
    STILL = still_windows(ws, nwin, gmag) if P["still"] else None
    del ws
    qs, bg_end = attitude(gsum, asum, cnt, nb, T_L, gmag)
    if hook:
        qs = hook("attitude", dict(qs=qs, nb=nb, info=info))
    pos, vel, K, kdt, gz = translation(asum, cnt, nb, qs, T_L, T_end)
    # body rate at the failure: mean bias-corrected gyro over the last 0.5 s of data (for the blind attitude)
    wL, nw_ = [0.0, 0.0, 0.0], 0
    for b in range(nb - 1, max(-1, nb - 1 - int(0.5 / P["bin_dt"])), -1):
        c = cnt[b]
        if c:
            for k in range(3):
                wL[k] += gsum[3 * b + k] / c - bg_end[k]
            nw_ += 1
    wL = [x / nw_ for x in wL] if nw_ else wL
    n_out = write_output(opener, info, out_path, qs, nb, pos, vel, K, kdt, T_L, wL)
    log(f"src={src} rows={st['rows']} out={n_out} dt={info['dt_nom']:.5f} gyro_first={info['gyro_first']} "
        f"ascale={info['ascale']:.3f} T_L={T_L:.2f}s bins={nb} knots={K}")
    log(f"platform {'rotorcraft' if plat else 'handheld'} (accel vibration {vib:.3f} m/s^2) {DIAG}")
    log(f"integrity {st}  still windows: {sum(STILL) if STILL is not None else 0} x 0.5 s")
    i0, i1 = min(2, len(JAM["sg"]) - 1), min(max(0, int(T_L) - 1), len(JAM["sg"]) - 1)
    log(f"jamming L={L:.3f} gamma={gam:.3f} | white noise gyro {JAM['sg'][i0]:.4f}->{JAM['sg'][i1]:.4f} rad/s, "
        f"accel {JAM['sa'][i0]:.4f}->{JAM['sa'][i1]:.4f} m/s^2")
    log(f"init g={gmag:.4f} calm@{INIT[3]*P['bin_dt']:.2f}s var={INIT[4]:.2e} bg0={INIT[1]} bg_end={bg_end} gz={gz:.4f}")
    return n_out
'''),
)

def _load_stages():
    g = globals()
    for name, text in _STAGES:
        code = compile(text, "src/stages/" + name + ".py", "exec")
        exec(code, g)
        del code


try:
    _load_stages()
    LOAD_ERROR = None
except Exception as _e:  # noqa: BLE001  (any failure -> stand-still output, never a crash)
    LOAD_ERROR = f"{type(_e).__name__}: {_e}"
# ----------------------------------------------------------------------------- END EMBEDDED STAGES


def parse_args(argv):
    """Positional [input] [output], or --input/-i and --output/-o (with a space or '='), plus --param=value.
    Unknown flags are reported and ignored: an evaluation harness must never be stopped by an argument."""
    inp = out = None
    pos_args, params = [], []
    a = list(argv[1:])
    while a:
        x = a.pop(0)
        if x in ("--input", "-i", "--output", "-o") and a:
            v = a.pop(0)
            if x in ("--input", "-i"):
                inp = v
            else:
                out = v
        elif x.startswith("--") and "=" in x:
            k, v = x[2:].split("=", 1)
            if k == "input":
                inp = v
            elif k == "output":
                out = v
            else:
                params.append((k, v))
        elif x.startswith("-") and len(x) > 1:
            print(f"pathguard: ignoring unknown option {x}", file=sys.stderr)
        else:
            pos_args.append(x)
    if inp is None and pos_args:
        inp = pos_args.pop(0)
    if out is None and pos_args:
        out = pos_args.pop(0)
    return inp, out or "estimated_trajectory.txt", params


def main(argv):
    inp, out, params = parse_args(argv)
    if LOAD_ERROR is not None:
        print(f"pathguard: cannot load the estimator ({LOAD_ERROR}); writing a stand-still trajectory", file=sys.stderr)
        fallback(inp, out)
        return
    for k, v in params:
        if k not in P:
            print(f"pathguard: ignoring unknown parameter {k}", file=sys.stderr)
            continue
        CLI_SET.add(k)
        P[k] = type(P[k])(float(v)) if not isinstance(P[k], str) else v
    try:
        run(inp, out)
    except Exception as e:  # never leave the evaluator without a well-formed trajectory
        print(f"pathguard: estimation failed ({type(e).__name__}: {e}); writing a stand-still trajectory", file=sys.stderr)
        fallback(inp, out)


def fallback(inp, out):
    """One pose per input row (position 0, identity attitude): the output contract holds for any input."""
    opener, _ = resolve_input(inp)
    with opener() as f, open(out, "w", newline="\n") as fo:
        fo.write("# timestamp tx ty tz qx qy qz qw\n")
        for line in f:
            s = line.strip()
            if not s or not (s[0].isdigit() or s[0] in "+-."):
                continue
            if "," not in s:
                s = s.replace(";", ",") if ";" in s else ",".join(s.split())
            tok = s.split(",", 1)[0].strip()
            try:
                ti, tf = parse_ts(tok)
            except ValueError:
                continue
            if ti is not None and ti >= 0:  # integer timestamps are nanoseconds (EuRoC format)
                ds = str(ti).rjust(10, "0")
                ts_s = ds[:-9] + "." + ds[-9:]
            else:
                ts_s = tok
            fo.write(ts_s + " 0.000000 0.000000 0.000000 0.000000000 0.000000000 0.000000000 1.000000000\n")


if __name__ == "__main__":
    main(sys.argv)
